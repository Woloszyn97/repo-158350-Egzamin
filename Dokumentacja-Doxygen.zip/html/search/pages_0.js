var searchData=
[
  ['repo_2d158350_2degzamin_22',['repo-158350-Egzamin',['../md__r_e_a_d_m_e.html',1,'']]]
];
