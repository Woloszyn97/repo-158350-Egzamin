var searchData=
[
  ['value_20',['value',['../class_my_sin.html#a1a86f17bf0f1b3f8ab06b27ceb9daace',1,'MySin::value()'],['../_my_sin_8cpp.html#a544800ab37a6b197b438ff034578b481',1,'value():&#160;MySin.cpp']]]
];
