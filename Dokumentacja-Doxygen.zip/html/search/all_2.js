var searchData=
[
  ['repo_2d158350_2degzamin_6',['repo-158350-Egzamin',['../md__r_e_a_d_m_e.html',1,'']]],
  ['readme_2emd_7',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]]
];
