var searchData=
[
  ['getx_15',['getX',['../class_my_sin.html#a465c516d38352e88df5a87097a8bb8a8',1,'MySin::getX()'],['../_my_sin_8cpp.html#a4ea08f9f96cf7655d673b4e772b8b000',1,'getX():&#160;MySin.cpp']]]
];
