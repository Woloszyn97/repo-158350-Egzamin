var searchData=
[
  ['setx_19',['setX',['../class_my_sin.html#a4b207c44bd5cefe56d643af283ffd609',1,'MySin::setX()'],['../_my_sin_8cpp.html#a81b05cbcdfa4aa4bd5b3a912f7abd660',1,'setX():&#160;MySin.cpp']]]
];
