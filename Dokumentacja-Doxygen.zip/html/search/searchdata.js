var indexSectionsWithContent =
{
  0: "gmrsv~",
  1: "m",
  2: "mr",
  3: "gmsv~",
  4: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje",
  4: "Strony"
};

